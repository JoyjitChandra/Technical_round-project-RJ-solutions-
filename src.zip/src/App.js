import './App.css';
import Test from './Components/test'
function App() {
  return (
   <div>
     <Test/>
    </div>
  );
}

export default App;
