import React,{useState} from 'react'
import Rectangle from './Rectangle'
import './style.css'
export default function Button() {
    const [state,setstate]=useState({value:false})
    const buttonchange=()=>{
        if(state.value===false){
        setstate({value:true})
        }
        else{
            setstate({value:false})
        }
    }
    const hellos=['Hello','Hello Hello','Hello Hello Hello','Hello Hello Hello Hello']
    return (
        <div>
            <div class='hello'>
            {hellos.map(e => (
        <h1>
          {e}
        </h1>
      ))}</div>
            <Rectangle child={state.value}/>
            <center><button onClick={buttonchange}>Press</button></center>  
            <center>{state.value?<center>Button Clicked</center>:null}       </center>
        </div>
    )
}
